create
    definer = root@`%` procedure GenerateSampleData()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE rand_gender CHAR(1);
    DECLARE rand_status TINYINT;
    DECLARE rand_birthday DATE;
    DECLARE rand_entry_date DATE;
    DECLARE rand_create_time DATETIME;
    DECLARE rand_update_time DATETIME;


    -- 循环生成10000条数据
    WHILE i <= 100000
        DO
            -- 随机生成性别（M/F）
            SET rand_gender = IF(RAND() > 0.5, '男', '女');

            -- 随机生成状态（0-2）
            SET rand_status = FLOOR(RAND() * 3);

            -- 生成随机生日（1998-01-01 到 2005-12-31）
            SET rand_birthday = DATE_ADD('1998-01-01',
                                         INTERVAL FLOOR(RAND() * (DATEDIFF('2005-12-31', '1998-01-01') + 1)) DAY);

            -- 生成随机入学日期（在生日后18-24年之间）
            SET rand_entry_date = DATE_ADD(rand_birthday,
                                           INTERVAL (18 + FLOOR(RAND() * 5)) YEAR);

            -- 确保入学日期不晚于今天
            IF rand_entry_date > CURDATE() THEN
                SET rand_entry_date = CURDATE();
            END IF;

            -- 创建时间（在入学日期之后，当前时间之前）
            SET rand_create_time = TIMESTAMPADD(SECOND,
                                                FLOOR(RAND() * TIMESTAMPDIFF(SECOND, rand_entry_date, NOW())),
                                                rand_entry_date);

            -- 更新时间（在创建时间之后，当前时间之前）
            SET rand_update_time = TIMESTAMPADD(SECOND,
                                                FLOOR(RAND() * TIMESTAMPDIFF(SECOND, rand_create_time, NOW())),
                                                rand_create_time);

            -- 插入随机数据
            INSERT INTO tb_stu (name,
                                age,
                                gender,
                                score,
                                birthday,
                                entryDate,
                                createTime,
                                updateTime,
                                status)
            VALUES (CONCAT('学生', i
                    ), -- 姓名
                    TIMESTAMPDIFF(YEAR, rand_birthday, CURDATE()), -- 年龄
                    rand_gender, -- 性别
                    ROUND(40 + RAND() * 60, 2), -- 分数（40.00-100.00）
                    rand_birthday, -- 生日
                    rand_entry_date, -- 入学日期
                    rand_create_time, -- 创建时间
                    rand_update_time, -- 更新时间
                    rand_status -- 状态
                   );

            SET i = i + 1;
        END WHILE;

    SELECT CONCAT('成功插入 ', i - 1, ' 条随机数据') AS Result;
END;

